# Erom Music — frontend original

Este pacote preserva o HTML original do frontend, copiado para `index.html`.
Inclui o manifesto e ícones mínimos que o HTML referencia.

## Publicar no Cloudflare Pages
1. Abra o painel do Cloudflare e vá a **Workers & Pages**.
2. Crie um projeto **Pages** com **Direct Upload** (ou use o projeto Pages apropriado).
3. Envie o conteúdo deste ZIP conforme o fluxo de upload do painel.
4. Teste a página publicada antes de trocar qualquer domínio ou rota.

## Importante
- Este pacote contém o frontend; não cria nem configura automaticamente banco, armazenamento ou credenciais.
- Não conecte um domínio público antes de configurar controle de acesso, caso queira que o site seja privado.
- Não envie segredos/chaves privadas dentro do HTML.
- O Worker existente `projectsx` não foi alterado por este pacote.
